window.YTD.verified.part0 = [
  {
    "verified" : {
      "accountId" : "1598268767510872064",
      "verified" : false
    }
  }
]